crée a but éducatif seulement par bcrblacki et lightning ;)
-----------------------
install / ISH / TERMUX|
-----------------------
1) apk add python3
2) apk add py3-pip
3) apk add git
4) git clone https://github.com/bcrblacki/light_lookup_mobile.git
5) cd light
6) pip install -r requirements.txt
8) python3 light.py
               
